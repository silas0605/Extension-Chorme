document.addEventListener('DOMContentLoaded', function(){

document.querySelector('#btn').addEventListener('click',function(){
	
	var i = document.getElementById('valor');
	var v = i.value;

	if (v == "17") {

		window.open('https://arte.engpro.totvs.com.br/protheus/padrao/builds/12.1.17-201808/latest/repositorio/lobo_guara/tttp120.rpo');

	} else if (v == '23') {

		window.open('https://arte.engpro.totvs.com.br/protheus/padrao/builds/12.1.23/latest/repositorio/lobo_guara/tttp120.rpo');

	} else if (v == '25') {

		window.open('https://arte.engpro.totvs.com.br/protheus/padrao/builds/12.1.25/latest/repositorio/lobo_guara/tttp120.rpo');

	} else if (v == '27') {

		window.open('https://arte.engpro.totvs.com.br/protheus/padrao/builds/12.1.27/latest/repositorio/lobo_guara/tttp120.rpo');

	} else if (v == '0') {

		window.alert('Selecione a vers�o do Protheus que deseja o RPO.')

	} else {

		alert('ERROR!');

	}	
})
})








